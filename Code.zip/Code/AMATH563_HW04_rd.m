%% RD

%% -1. Run the RD Simulation
tic
fprintf('\n -1. Running the RD equation:\n')

RD_Plots = 0;
ICs = 2;
RD_iters = 10;
fprintf('\nICs = %d...',ICs)
fprintf('\nPlots_RD = %d...',RD_Plots)
fprintf('\nSimulating RD equation %d times...\n',RD_iters)
for RD_ct = 1 : RD_iters
    fprintf('\nRD_ct = %d; ',RD_ct)
    run reaction_diffusion.m
    clearvars -except RD_iters RD_ct RD_Plots ICs 
end

fprintf('\n\nFinished running RD equation %d times. ',RD_iters)
toc
fprintf('\n\n')


%% 0. Specify simulation parameters

% Choose which set of ICS to use
ICs = 2;

% Choose rank reconstruction
rank_rec = 201;

% Choose number of iterations to train on
RD_iters = 10;

% Choose range of uniform randomized noise
ns_lw = 0.95;
ns_hg = 1.05;
range = round((ns_hg - ns_lw)*100);

% Choose number of spirals
m = 2;


%% 1. Read in data files
tic
fprintf('\n1. Reading in data files for the following parameters:')
fprintf('\nICs = %d',ICs)
fprintf('\nrank_rec = %d',rank_rec)
fprintf('\nRD_iters = %d',RD_iters)
fprintf('\nns_lw = %0.3f',ns_lw)
fprintf('\nns_lw = %0.3f',ns_hg)
fprintf('\nm = %d',m)

for RD_ct = 1 : RD_iters
    fprintf('\n\n RD_ct = %d',RD_ct)
    fld_pth = sprintf('RD_ICs%d_iter%d_lw%03d_hg%03d_m%d',ICs,RD_iters,ns_lw*100,ns_hg*100,m);
    cd(fld_pth)
    fil_lod = sprintf('RD_ICs%d_iter%d_lw%03d_hg%03d_m%d.mat',ICs,RD_ct,ns_lw*100,ns_hg*100,m);
    load(fil_lod)

    if RD_ct == 1
        % Identify basic parameters of the RD solution
        Nx = length(x);
        Lx = x(end);
        Ny = length(y);
        Ly = y(end);
        T = t(end);
        h = t(end) - t(end-1);
        Nt = round(T/h + 1);
        
        % Sneaky preallocation
        uv_inp_ICs = zeros(Nx*Ny*2,149*RD_iters);
        uv_otp_ICs = zeros(Nx*Ny*2,149*RD_iters);
        uv_tst_ICs = zeros(Nx*Ny*2,51*RD_iters);
    end

    % Reshape the u and v arrays
    fprintf('\nReshaping arrays...');
    u_input = zeros(Nx*Ny,Nt);
    v_input = zeros(Nx*Ny,Nt);
    for tstep = 1 : Nt
        u_input(:,tstep) = reshape(u(:,:,tstep),Nx*Ny,1);
        v_input(:,tstep) = reshape(v(:,:,tstep),Nx*Ny,1);
    end

    % Form the data matrix
    fprintf('\nForming data matrix...')
    uv = [
        u_input
        v_input
        ];

    % SVD of the data matrix
    fprintf('\nTaking SVD...')
    [U_uv,S_uv,V_uv] = svd(uv,'econ');
    V_uv = conj(V_uv)';
    rank_uv = length(S_uv);

    % Form reconstructions
    fprintf('\nForming rank %d reconstructions...',rank_rec)
    uv_rec = U_uv(:,1:rank_rec) * S_uv(1:rank_rec,1:rank_rec) * V_uv(1:rank_rec,:);

    % Form input and output matrices
    fprintf('\nForming input and output matrices...')
    t_train_end = 150;
    uv_inp_rec = uv_rec(:,1:t_train_end-1);
    uv_otp_rec = uv_rec(:,2:t_train_end);

    % Form testing matrices
    fprintf('\nForming testing matrices...')
    uv_tst_rec = uv_rec(:,t_train_end+1:end);
    
    uv_inp_ICs(:,(1+(t_train_end-1)*(RD_ct-1)):((t_train_end-1)*RD_ct)) = uv_inp_rec;
    uv_otp_ICs(:,(1+(t_train_end-1)*(RD_ct-1)):((t_train_end-1)*RD_ct)) = uv_otp_rec;
    uv_tst_ICs(:,(1+(Nt-t_train_end)*(RD_ct-1)):((Nt-t_train_end)*RD_ct)) = uv_tst_rec;
    
    cd('/Users/josephwilliams/Documents/MATLAB/')
    
end
fprintf('\n\nFinished initialization. ')
toc
fprintf('\n\n')


%% 1.5 Plot the ICs of each realization of ICs = 2, Noisy RD

for RD_ct = 1 : RD_iters
    figure
    pcolor(x,y,reshape(uv_inp_ICs(1:Nx*Ny,(1+(t_train_end-1)*(RD_ct-1))),[Nx Ny]))
    shading interp
    colormap(hot)
    colorbar
    caxis([-1 1])
    
    xlabel('x', 'fontsize',32)
    ylabel('y', 'fontsize',32)
    ttl_str = sprintf('u(x,y) at t = %d, ICs = %d',(RD_ct-1)*(t_train_end-1)+1,ICs);
    title(ttl_str, 'fontsize',20)
    
end


%% 2. NN
tic
fprintf('\n2. Building and training the reaction-diffusion neural network:\n')

% Build the layers
fprintf('\nBuilding the layers...')
numFeatures = Nx * Ny * 2;
numResponses = Nx * Ny * 2;
numHiddenUnits = 25;

layers = [ ...
    sequenceInputLayer(numFeatures)
    tanhLayer
    lstmLayer(numHiddenUnits)
    fullyConnectedLayer(numResponses)
    regressionLayer];

% Set the network options
fprintf('\nSetting the options...')
solver = sprintf('adam');
max_epochs = 100;
options = trainingOptions(solver, ...
    'MaxEpochs',max_epochs, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.005, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'Verbose',0, ...
    'Plots','training-progress');

% Train the network
fprintf('\nTraining the network...\n')
[net,info] = trainNetwork(uv_inp_ICs,uv_otp_ICs,layers,options);

fprintf('\nFinished training the network. ')
toc
fprintf('\n\n')


%% 2.5 Load the ICs = 1 data

fprintf('\n2.5 Loading ICs = 1 data:\n')
clear t x y u v
fil_lod = sprintf('RD_ICs%d_m%d.mat',1,m);
load(fil_lod)

% Reshape the u and v arrays
fprintf('\nReshaping arrays...');
u_input = zeros(Nx*Ny,Nt);
v_input = zeros(Nx*Ny,Nt);
for tstep = 1 : Nt
    u_input(:,tstep) = reshape(u(:,:,tstep),Nx*Ny,1);
    v_input(:,tstep) = reshape(v(:,:,tstep),Nx*Ny,1);
end

% Form the data matrix
fprintf('\nForming data matrix...')
uv = [
    u_input
    v_input
    ];

% SVD of the data matrix
fprintf('\nTaking SVD...')
[U_uv,S_uv,V_uv] = svd(uv,'econ');
V_uv = conj(V_uv)';
rank_uv = length(S_uv);

% Form reconstructions
fprintf('\nForming rank %d reconstructions...',rank_rec)
uv_rec = U_uv(:,1:rank_rec) * S_uv(1:rank_rec,1:rank_rec) * V_uv(1:rank_rec,:);

% Form input and output matrices
fprintf('\nForming input and output matrices...')
t_train_end = 150;
uv_inp_rec = uv_rec(:,1:t_train_end-1);
uv_otp_rec = uv_rec(:,2:t_train_end);

% Form testing matrices
fprintf('\nForming testing matrices...')
uv_tst_rec = uv_rec(:,t_train_end+1:end);

fprintf('\n\nFinished initialization. ')
toc
fprintf('\n\n')


%% 4. Make predictions with the ICs = 1 data

pred = predict(net,uv_rec(:,1:end-1));

fprintf('\nCalculating the errors...')
errs_2d = (pred - uv_rec(:,2:end));
l2_err_norm = sqrt(sum( (errs_2d.^2) ) );
l2_err_norm_u = sqrt(sum( (errs_2d(1:Nx*Ny,:).^2) ) );
l2_err_norm_v = sqrt(sum( (errs_2d(Nx*Ny+1:2*Nx*Ny,:).^2) ) );

errs_3d_u = zeros(Nx,Ny,size(uv_rec,2));
errs_3d_v = zeros(Nx,Ny,size(uv_rec,2));
for tstep = 1 : size(uv_rec,2)-1
    errs_3d_u(:,:,tstep) = reshape(errs_2d(1:Nx*Ny,tstep),[64,64,1]);
    errs_3d_v(:,:,tstep) = reshape(errs_2d(Nx*Ny+1:2*Nx*Ny,tstep),[64,64,1]);
end

% Plot L2 norm of the errors
fprintf('\nPlotting the L2 norm of the errors of the solution')
figure
hold on
plot(2 : size(uv_rec,2),l2_err_norm_u, 'b.--')
plot(2 : size(uv_rec,2),l2_err_norm_v, 'r.--')
plot(2 : size(uv_rec,2),l2_err_norm, 'g.--')
plot([150 150],[0 100], 'k--', 'linewidth',1)
axis([0 size(uv_rec,2) 0 100])

xlabel('t', 'fontsize',32)
ylabel('\epsilon', 'fontsize',32)
title({['L^2(\epsilon) vs. t'], ...
    ['m = ',sprintf('%d',m), ', \nu = ',sprintf('%d',round((ns_hg-ns_lw)*100)), '; Rank Reconstruction r = ',sprintf('%d',rank_rec)] }, ...
    'fontsize',20)

lgd_1 = sprintf('u');
lgd_2 = sprintf('v');
lgd_3 = sprintf('Both');
legend(lgd_1,lgd_2,lgd_3, 'location','northwest')

[max_err,max_err_t] = max(l2_err_norm);
[min_err,min_err_t] = min(l2_err_norm);
[mn1_err] = mean(l2_err_norm(1:149));
[mn2_err] = mean(l2_err_norm(150:200));

% dim = [.15 0.60 .195 .15];
% str = sprintf('Max: %0.2f at t = %d\nMin: %0.4f at t = %d\nMean_1: %0.2f\nMean_2: %0.2f',max_err,max_err_t, min_err,min_err_t,  mn1_err, mn2_err);
% annotation('textbox',dim,'String',str);

fprintf('\nSaving L2 norm of error data...')
fil_ttl = sprintf('L2_norm_lw%03d_hg%03d_m%d_r%d',ns_lw*100,ns_hg*100,m,rank_rec);
save(fil_ttl,'l2_err_norm','l2_err_norm_u','l2_err_norm_v')

fprintf('\n\nFinished post-processing. ')
toc
fprintf('\n\n')


%% Misc.

tplot = 2;

% Actual and predicted u
figure
pcolor(x,y, reshape( pred(1:Nx*Ny,tplot-1),[Nx Ny]))
shading interp
colormap(hot)
colorbar
caxis([-1 1])
xlabel('x', 'fontsize',32)
ylabel('y', 'fontsize',32)
ttl_str = sprintf('Predicted u(x,y) at t = %d, ICs =  %d',tplot,ICs);
title(ttl_str, 'fontsize',20)

figure
pcolor(x,y, reshape( uv_rec(1:Nx*Ny,tplot),[Nx Ny]))
shading interp
colormap(hot)
colorbar
caxis([-1 1])
xlabel('x', 'fontsize',32)
ylabel('y', 'fontsize',32)
ttl_str = sprintf('Actual u(x,y) at t = %d, ICs =  %d',tplot,ICs);
title(ttl_str, 'fontsize',20)

% Actual and predicted v
figure
pcolor(x,y, reshape( pred(Nx*Ny+1:2*Nx*Ny,tplot-1),[Nx Ny]))
shading interp
colormap(hot)
colorbar
caxis([-1 1])
xlabel('x', 'fontsize',32)
ylabel('y', 'fontsize',32)
ttl_str = sprintf('Predicted v(x,y) at t = %d, ICs =  %d',tplot,ICs);
title(ttl_str, 'fontsize',20)

figure
pcolor(x,y, reshape( uv_rec(Nx*Ny+1:2*Nx*Ny,tplot),[Nx Ny]))
shading interp
colormap(hot)
colorbar
caxis([-1 1])
xlabel('x', 'fontsize',32)
ylabel('y', 'fontsize',32)
ttl_str = sprintf('Actual v(x,y) at t = %d, ICs =  %d',tplot,ICs);
title(ttl_str, 'fontsize',20)



%% KS

%% -1. Run the KS Simulation
tic
fprintf('\n -1. Running the KS equation:\n')

ns_lw = 0.75;
ns_hg = 1.25;

KS_Plots = 1;
ICs = 2;
if ICs == 1
    KS_iters = 1;
elseif ICs == 2
    KS_iters = 100;
end
fprintf('\nICs = %d...',ICs)
fprintf('\nPlots_KS = %d...',KS_Plots)
fprintf('\nSimulating KS equation %d times...\n',KS_iters)
fprintf('\nns_lw = %0.3f and ns_hg = %0.3f',ns_lw,ns_hg)
for KS_ct = 1 : KS_iters
    fprintf('\nKS_ct = %d; ',KS_ct)
    run kuramoto_sivashinky.m
    clearvars -except KS_iters KS_ct KS_Plots ICs ns_lw ns_hg
end

fprintf('\n\nFinished running KS equation %d times. ',KS_iters)
toc
fprintf('\n\n')


%% 0. Specify simulation parameters

% Choose which set of ICS to use
ICs = 2;

% Choose number of iterations to train on
KS_iters = 100;

% Choose range of uniform randomized noise
ns_lw = 0.95;
ns_hg = 1.05;
range = round((ns_hg - ns_lw)*100);


%% 1. Read in data files
tic
fprintf('\n1. Reading in data files for the following parameters:')
fprintf('\nICs = %d',ICs)
fprintf('\nKS_iters = %d',KS_iters)
fprintf('\nns_lw = %0.3f',ns_lw)
fprintf('\nns_lw = %0.3f',ns_hg)

for KS_ct = 1 : KS_iters
    fprintf('\n\n KS_ct = %d',KS_ct)
%     fld_pth = sprintf('KS_ICs%d_iter%d_lw%03d_hg%03d',ICs,KS_iters,ns_lw*100,ns_hg*100,m);
%     cd(fld_pth)
    fil_lod = sprintf('KS_ICs%d_iter%d_lw%03d_hg%03d.mat',ICs,KS_ct,ns_lw*100,ns_hg*100);
    load(fil_lod)

    if KS_ct == 1
        % Identify basic parameters of the RD solution
        Nx = length(x);
        Lx = x(end);
        T = tt(end);
        h = tt(end) - tt(end-1);
        Nt = round(T/h + 1);
        
        % Sneaky preallocation
        uu_inp_ICs = zeros(Nx,174*KS_iters);
        uu_otp_ICs = zeros(Nx,174*KS_iters);
        uu_tst_ICs = zeros(Nx,77*KS_iters);
    end
    
    t_train_end = 175;
    
%     uu_inp_ICs(:,
    
    uu_inp_ICs(:,(1+(t_train_end-1)*(KS_ct-1)) : ((t_train_end-1)*KS_ct)) = uu(:,1:(t_train_end-1));
    uu_otp_ICs(:,(1+(t_train_end-1)*(KS_ct-1)) : ((t_train_end-1)*KS_ct)) = uu(:,1+1:(t_train_end));
    uu_tst_ICs(:,(1+(Nt-t_train_end)*(KS_ct-1)) : ((Nt-t_train_end)*KS_ct)) = uu(:,(t_train_end+1):end);
    
end

fprintf('\n\nFinished.\n')



%% Build and Train NN

fprintf('Building neural net...\n')
tic
numFeatures = Nx;
numResponses = Nx;
numHiddenUnits = 50;

layers = [ ...
    sequenceInputLayer(numFeatures)
    tanhLayer
    lstmLayer(numHiddenUnits)
    fullyConnectedLayer(numResponses)
    regressionLayer];

solver = sprintf('adam');
max_epochs = 250;
options = trainingOptions(solver, ...
    'MaxEpochs',max_epochs, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.005, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'Verbose',0, ...
    'Plots','training-progress');

[net,info] = trainNetwork(uu_inp_ICs, uu_otp_ICs, layers,options);



%%

fil_lod = sprintf('KS_ICs%d.mat',1);
load(fil_lod)

uu_pred_test = uu(:,1:end-1);

pred = predict(net,uu_pred_test(:,1:end-1));


%%

fprintf('\nCalculating the errors...')
errs_2d = (pred - uu_pred_test(:,2:end));
l2_err_norm = sqrt(sum( (errs_2d.^2) ) );

% Plot L2 norm of the errors
fprintf('\nPlotting the L2 norm of the errors of the solution')
figure
hold on
plot(2 : size(uu_pred_test,2),l2_err_norm, 'g.--')
plot([t_train_end t_train_end],[0 100], 'k--', 'linewidth',1)
axis([0 size(uu_pred_test,2) 0 100])

xlabel('t', 'fontsize',32)
ylabel('\epsilon', 'fontsize',32)
title({['L^2(\epsilon) vs. t, KS Equation'], ...
    ['\nu = ',sprintf('%d',round((ns_hg-ns_lw)*100)),  ', \tau = ',sprintf('%d',KS_iters)] }, ...
    'fontsize',20)




%%

fprintf('\n\nPost-processing:\n')

fprintf('Plotting RMSE vs Epoch and mean(L2) vs. t...\n')

if solver == 'adam';
    solver_str = sprintf('Adam');
elseif solver == 'sgdm';
    solver_str = sprintf('SGDM');
end

% RMSE vs. Epoch
figure
plot(1:max_epochs,info.TrainingRMSE, 'b.--')
xlabel('Epochs', 'fontsize',20)
ylabel('RMSE', 'fontsize',20)
ttl_str = sprintf('RMSE of each Epoch\nLSTM: %s, h = %d, Ep. = %d',solver_str,numHiddenUnits,max_epochs);
title(ttl_str, 'fontsize',20)
axis([0 max_epochs 0 35])

dim = [.15 0.80 .125 .045];
str = sprintf('Min: %0.4f',min(info.TrainingRMSE));
annotation('textbox',dim,'String',str);


% Mean-across-x of L2 Norm vs. t
errs = sqrt((uu_output - pred).^2);
errs_mean_t = mean(errs)';
[max_errs_mean_t,I_max] = max(errs_mean_t);
[min_errs_mean_t,I_min] = min(errs_mean_t);

figure
plot(h:h:tmax,errs_mean_t, 'b.--')
axis([0 tmax 0 0.250])

xlabel('t', 'fontsize',32)
ylabel('$\bar{\epsilon}$','Interpreter','Latex', 'fontsize',32)
ttl_str = sprintf('Avg. L_2 Error vs. t\nLSTM: %s, h = %d, Ep. = %d',solver_str,numHiddenUnits,max_epochs);
title(ttl_str, 'fontsize',20)

dim = [.15 0.70 .215 .135];
str = sprintf('Max: %0.4f at t = %0.2f\nMin: %0.4f at t = %0.2f\nMean: %0.4f\nMedian: %0.4f',max_errs_mean_t,I_max*h,min_errs_mean_t,I_min*h,mean(errs_mean_t),median(errs_mean_t));
annotation('textbox',dim,'String',str);


%% Plots - DFN
% 
% % Plots
% tplot_1 = 2;
% tplot_2 = 100;
% figure
% hold on
% plot(1:N,uu_output(:,tplot_1-1), 'b.--')
% plot(1:N,pred(:,tplot_1-1), 'c.--')
% plot(1:N,uu_output(:,tplot_2-1), 'r.--')
% plot(1:N,pred(:,tplot_2-1), 'm.--')
% 
% xlabel('x', 'fontsize',20)
% ylabel('KS(x,1)', 'fontsize',20)
% ttl_str = sprintf('KS(x,1)');
% title(ttl_str, 'fontsize',20)
% 
% lgd_1 = sprintf('Test: t = %d',tplot_1);
% lgd_2 = sprintf('Pred: t = %d',tplot_1);
% lgd_3 = sprintf('Test: t = %d',tplot_2);
% lgd_4 = sprintf('Pred: t = %d',tplot_2);
% legend(lgd_1, lgd_2, lgd_3, lgd_4, 'location','southeast', 'fontsize',20)
% 
% % Errors
% errs_1 = sqrt((uu_output(:,tplot_1-1) - pred(:,tplot_1)).^2);
% errs_2 = sqrt((uu_output(:,tplot_2-1) - pred(:,tplot_2)).^2);
% 
% figure
% hold on
% plot(1:N, errs_1)
% plot(1:N, errs_2)
% 
% xlabel('x', 'fontsize',20)
% ylabel('L_2[y - y_0]', 'fontsize',20)
% ttl_str = sprintf('L2 Norm of the Error at each Point');
% title(ttl_str, 'fontsize',20)
% 
% lgd_1 = sprintf('t = %d',tplot_1);
% lgd_2 = sprintf('t = %d',tplot_2);
% legend(lgd_1, lgd_2, 'location','northeast', 'fontsize',20)

%% Figure of KS Equation

figure
pcolor(x,tt,uu.')
shading interp
colormap(hot)

xlabel('x', 'fontsize',20)
ylabel('t', 'fontsize',20)
ttl_str = sprintf('KS Eqn: u(x,t)');
title(ttl_str, 'fontsize',20)

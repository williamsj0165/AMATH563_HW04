%% LZ
tic

% Simulate Lorenz system
dt=0.01;
T=8;
t=0:dt:T;

b=8/3;
sig=10;
r=40;
    
Lorenz = @(t,x)([ sig * (x(2) - x(1)) ; ...
r * x(1)-x(1) * x(3) - x(2) ; ...
x(1) * x(2) - b*x(3) ]);
ode_options = odeset('RelTol',1e-10, 'AbsTol',1e-11);
input=[]; output=[];

tau = 100;
for j=1:tau % training trajectories
    x0=30*(rand(3,1)-0.5);
    [t,y] = ode45(Lorenz,t,x0);
    input=[input; y(1:end-1,:)];
    output=[output; y(2:end,:)];
    plot3(y(:,1),y(:,2),y(:,3))
    hold on
    plot3(x0(1),x0(2),x0(3),'ro')
end




%%

fprintf('Building neural net...\n')
tic
numFeatures = 3;
numResponses = 3;
numHiddenUnits = 50;

layers = [ ...
    sequenceInputLayer(numFeatures)
    tanhLayer
    lstmLayer(numHiddenUnits)
    fullyConnectedLayer(numResponses)
    regressionLayer];

solver = sprintf('adam');
max_epochs = 100;
options = trainingOptions(solver, ...
    'MaxEpochs',max_epochs, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.005, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'Verbose',0, ...
    'Plots','training-progress');

[net,info] = trainNetwork(input', output', layers,options);


%%
% Simulate Lorenz system
dt=0.01;
T=8;
t=0:dt:T;

b=8/3;
sig=10;
% r_pred = 17;
r_pred = 35;
    
Lorenz = @(t,x)([ sig * (x(2) - x(1)) ; ...
r_pred * x(1)-x(1) * x(3) - x(2) ; ...
x(1) * x(2) - b*x(3) ]);
ode_options = odeset('RelTol',1e-10, 'AbsTol',1e-11);
input_pred=[]; output_pred=[];

x0=[30 30 30];
[t,y] = ode45(Lorenz,t,x0);
input_pred=[input_pred; y(1:end-1,:)];
output_pred=[output_pred; y(2:end,:)];
plot3(y(:,1),y(:,2),y(:,3))


%%

pred = predict(net, input_pred');

fprintf('\nCalculating the errors...')
errs_2d = (pred - output_pred');
l2_err_norm = sqrt(sum( (errs_2d.^2) ) );

% Plot L2 norm of the errors
fprintf('\nPlotting the L2 norm of the errors of the solution')
figure
hold on
plot(1:800,l2_err_norm, 'g.--')
% axis([0 size(output_pred,2) 0 100])

xlabel('t', 'fontsize',32)
ylabel('\epsilon', 'fontsize',32)
title({['L^2(\epsilon) vs. t, Lorenz System: \rho_{train} = ',sprintf('%d',r)], ...
    ['\rho_{pred} = ',sprintf('%d',r_pred), ', \tau = ',sprintf('%d',tau)] }, ...
    'fontsize',20)

